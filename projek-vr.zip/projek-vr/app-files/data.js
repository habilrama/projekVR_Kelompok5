var APP_DATA = {
  "scenes": [
    {
      "id": "0-halaman-depan-museum",
      "name": "Halaman Depan Museum",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -0.2119328377421681,
        "pitch": -0.18799930491153383,
        "fov": 1.325599857056214
      },
      "linkHotspots": [
        {
          "yaw": -0.43206601832549296,
          "pitch": 0.06866652608797885,
          "rotation": 0,
          "target": "1-dalam-pameran-roket-dan-astronot"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-dalam-pameran-roket-dan-astronot",
      "name": "Dalam (Pameran Roket dan Astronot)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -0.42920852013330446,
        "pitch": 0.007509062115142129,
        "fov": 1.325599857056214
      },
      "linkHotspots": [
        {
          "yaw": 0.898740887371023,
          "pitch": 0.24384830398658153,
          "rotation": 0,
          "target": "2-dalam-pameran-roket-dan-astronot-1"
        },
        {
          "yaw": 3.0032546093915844,
          "pitch": 0.12301541286681683,
          "rotation": 0,
          "target": "0-halaman-depan-museum"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-dalam-pameran-roket-dan-astronot-1",
      "name": "Dalam (Pameran Roket dan Astronot 1)",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.325599857056214
      },
      "linkHotspots": [
        {
          "yaw": -1.0061753515653944,
          "pitch": 0.17954924337474942,
          "rotation": 0,
          "target": "3-planetrarium"
        },
        {
          "yaw": 1.4996302830508963,
          "pitch": 0.21223431817412575,
          "rotation": 0,
          "target": "1-dalam-pameran-roket-dan-astronot"
        }
      ],
      "infoHotspots": [
        {
          "yaw": -0.4669200324248415,
          "pitch": -0.09137006769830691,
          "title": "Roket",
          "text": "kendaraan yang digunakan untuk membawa <span data-start=\"200\" data-end=\"237\" style=\"\">astronaut, satelit, dan peralatan</span> ke luar angkasa dengan cara menghasilkan <span data-start=\"279\" data-end=\"322\" style=\"\">gaya dorong dari pembakaran bahan bakar</span>."
        },
        {
          "yaw": 0.10288068667807337,
          "pitch": 0.18771809667374662,
          "title": "Baju Astronaut (Spacesuit)",
          "text": "pakaian khusus yang dirancang untuk <span data-start=\"741\" data-end=\"781\" style=\"\">melindungi astronaut di luar angkasa</span>, di mana tidak ada udara dan suhu sangat ekstrem."
        },
        {
          "yaw": 0.832860146669617,
          "pitch": -0.20046988100176577,
          "title": "Pendorong Roket&nbsp;<div>(Rocket Propulsion)</div>",
          "text": "&nbsp;sistem yang menghasilkan <span data-start=\"250\" data-end=\"265\" style=\"\">gaya dorong</span> sehingga roket dapat lepas dari bumi dan bergerak di luar angkasa."
        }
      ]
    },
    {
      "id": "3-planetrarium",
      "name": "Planetrarium",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -0.2968682995379215,
        "pitch": -0.0029453738844864574,
        "fov": 1.325599857056214
      },
      "linkHotspots": [
        {
          "yaw": 1.5002759912838641,
          "pitch": 0.2176596934348929,
          "rotation": 7.0685834705770345,
          "target": "2-dalam-pameran-roket-dan-astronot-1"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Projek VR",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
